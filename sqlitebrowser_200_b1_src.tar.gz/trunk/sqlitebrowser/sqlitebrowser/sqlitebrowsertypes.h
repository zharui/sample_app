/*types for encoded media data*/
enum
{
	kSQLiteMediaType_Void,
	kSQLiteMediaType_Integer,
	kSQLiteMediaType_String,
	kSQLiteMediaType_Binary
};



